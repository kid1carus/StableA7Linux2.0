#include <stdio.h>

class C {
 public:
  C() {}
};

int main() {
  C c;
  puts("OK");
}
