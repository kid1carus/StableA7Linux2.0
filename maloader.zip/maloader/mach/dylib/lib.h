extern int check_value;

int hello(const char* arg);
