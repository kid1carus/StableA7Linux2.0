#include <stdio.h>

int main() {
  return fflush(NULL);
}
