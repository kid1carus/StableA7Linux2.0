#include <stdio.h>

int main() {
  fprintf(stderr, "Hello, world!\n");
  return 0;
}
